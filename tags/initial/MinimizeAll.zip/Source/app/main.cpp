#include "minimize_all.h"

#include <Application.h>

int main() {

	be_app = new BApplication("application/x-vnd.pecora-minimizeall");

	minimize_all();
	return 0;

	delete be_app;
	
}